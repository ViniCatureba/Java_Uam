public class Automovel extends Veiculo {
    @Override
    public void acelerar(){
        velocidade++;
    }

    
}
